<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function __contruct()
	{
		$this->load->helper(array('url','form'));
        $this->load->database();
		$this->load->library(array("form_validation","session"));
	}
	public function index()
	{
		$this->load->model('Contact');
		$data['myData'] = $this->Contact->get_all_contact();
		$this->load->view('main',$data);
	}
	public function new()
	{
		$this->load->view('main/new');
	}
	public function show($id)
	{
		$this->load->model('Contact');
		$data['myData'] = $this->Contact->get_contact_by_id($id);
		$this->load->view('main/show',$data);
	}
	
	 public function edit($id)
	{
		$this->load->model('Contact');
		$data['myData'] = $this->Contact->get_contact_by_id($id);
		$this->load->view('main/edit',$data);
	} 
	public function remove($id)
	{
		$this->load->model('Contact');
		$data['myData'] = $this->Contact->get_contact_by_id($id);
		$this->load->view('main/remove',$data);
	} 
	public function create()
	{
		$this->load->library('form_validation');
		$this->load->model('Contact');
		$post = $this->input->post();
		$result = $this->validates($post);
		if($result == true){
			$create = $this->Contact->create_contact($post);
			if($create){
				redirect('main');
			}
		}

	}
	public function update()
	{
		$post = $this->input->post();
		$this->load->library('form_validation');
		$this->load->model('Contact');
		$result = $this->validates($post);
		if($result == true){
			$update = $this->Contact->update_contact($post);
			if($update){
				redirect('main');
			}
		}
	}
	public function delete($id)
	{
		$this->load->model('Contact');
		$result = $this->Contact->delete_contact($id);
		if($result === true){
			redirect('main');
		}else{
			echo "there is an error deleting this bookmark";
			$this->load->view('main');
		}
	}
	
	public function validates($post)
	{
		$this->form_validation->set_rules('number','Number','required');
		$this->form_validation->set_rules('name','Name','trim|required');
		if($this->form_validation->run() === False ){
			return FALSE;
		}else{
			return true;
		}
	}

}
