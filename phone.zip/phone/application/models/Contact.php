<?php
    class Contact extends CI_Model{
        public function __construct(){
            $this->load->database();
        }
        function get_all_contact(){
            $query = "Select * from contact";
            return $this->db->query($query);
        }
        function create_contact($post){
            $query = "Insert into contact (name,number,created_at,updated_at)  values ('{$post['name']}','{$post['number']}',Now(),Now())";
            
            return $this->db->query($query);
        }
        function get_contact_by_id($id){
            $query = "Select * from contact where id = $id";
            return $this->db->query($query);
        }
        function update_contact($post){
            $query = "UPDATE contact 
                    Set name='".$post['name']."',number='".$post['number']."' 
                    where id = '".$post['id']."'";
            echo $query;
            return $this->db->query($query);
        }
        function delete_contact($id){
            $query = "Delete from contact where id='".$id."'";
            return $this->db->query($query);
        }
    }

?>