<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	#body {
		position:absolute;
		left:50%;
		top:50%;
		transform: translate(-50%, -50%);
		background-color: #D0B8A8;
		border: 2px solid black; 
		padding: 0px 20px;
		border-radius: 12%;
	}

	p {
		margin: 0 0 10px;
		padding:0;
	}

	#body table tr th{
		background-color: #E8DFCA;
		color:#AEBDCA;
		border: 2px solid #7895B2;	
	}

	</style>
</head>
<body>

<div id="container">
	

	<div id="body">
	<h1>Contacts</h1>
		<table>
			<tr>
				<th>Name</th>
				<th>Contact Number</th>
				<th>Actions</th>
			</tr>
			<tr>
			<?php foreach($myData->result() as $myDatas){?>
				<tr>
					<tbody>
					<td><?= $myDatas->name;?></td>
					<td><?= $myDatas->number;?></td>
					<td><a href="<?= base_url("main/show/$myDatas->id")?>">Show</a> | <a href="<?= base_url("main/edit/$myDatas->id")?>">Edit</a>  | <button><a href="<?= base_url("main/remove/$myDatas->id")?>">Remove</a></button></td>
				</tbody>
				
			</tr>
			<?php }?>
		</table>
		<p><a href="<?= base_url('main/new')?>">Add new Contact</a></p>
	</div>
	
	
	
</div>

</body>
</html>
