<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

	<style type="text/css">

	::selection { background-color: #E13300; color: white; }
	::-moz-selection { background-color: #E13300; color: white; }

	body {
		background-color: #fff;
		margin: 40px;
		font: 13px/20px normal Helvetica, Arial, sans-serif;
		color: #4F5155;
	}

	#body {
		position:absolute;
		left:50%;
		top:50%;
		transform: translate(-50%, -50%);
		border: 2px solid black; 
		background-color: #D0B8A8;
		padding: 10px 20px;
		border-radius: 12%;
	}

	p {
		margin: 0 0 10px;
		padding:0;
	}

	#body table tr th{
		background-color: #E8DFCA;
		color:#AEBDCA;
		border: 2px solid #7895B2;	
	}
	.submit{
		background-color: #B1D7B4;
		color: #319DA0 
	}

	</style>
</head>
<body>

<div id="container">
	<div id="body">
<?php foreach($myData->result() as $myDatas){?>	
		<p><a href="<?= base_url('main')?>">Go Back</a> | <a href="<?= base_url("main/show/$myDatas->id")?>">Show</a></p>
		<h1>Edit contact</h1>
		<form action="<?= base_url('main/update')?>" method="post">
			<p><label>Name: </p><p><input type="text" name="name" value="<?= $myDatas->name;?>"></label></p>
			<p><label>Contact number: </p><p><input type="text" name="number" value="<?= $myDatas->number;?>"></label></p>	
			<p><input type="hidden" name="id"  value=<?= $myDatas->id?>><input type="submit" value="Update"  class="submit"></p>	
		</form>	
	<?php } ?>
	</div>	
</div>
</body>
</html>
