<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {

	
	public function index()
	{
		$this->load->view('Main');
	}
	public function proc(){
		$this->load->library('session');
		$winner = $this->session->userdata('winner');
		$rand = rand(0000000, 9999999);
		if($this->input->post('action')!==null && $this->input->post('action') == 'addwinner'){
			$winner = $this->input->post('winner');
			$winner +=1;
		}else{
			$winner = 0;
		}		
		$newdata = array('winner'=>$winner,);
		$data['winner'] = $winner;
		$data['random'] = $rand; 
		
		$this->load->view('Main', $data);
		$this->session->set_userdata($newdata);
	}
	public function reset(){
		$this->load->library('session');
		$this->session->unset_userdata('winner');
		redirect('main');
	}
}
