<div class="modal fade" id="addEmployee" tabindex="-1" aria-labelledby="addEmployeeLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="addEmployeeLabel">Add Employee</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="proc.php" method="post" class="form-control">
                            <div class="row">
                                <input type="hidden" name="action" value="add_employee" >
                                <div class="form-group"> 
                                    <label for="empname" class="label">Employee Name</label>
                                    <input type="text" name="empname" placeholder="empname" class="form-control">
                                </div>
                               
                                <div class="form-group">
                                    <label for="address">Address</label>
                                    <input type="text" name="address" placeholder="address" class="form-control">
                                </div>
                                

                                <div class="form-group">
                                <label for="bday">Birth Date</label>
                                <input type="date" name="bday" placeholder="Birth date" class="form-control">
                                </div>
                                
                                <div class="form-group">
                                    <label for="age">Age</label>
                                    <input type="number" name="age" placeholder="number" class="form-control">
                                </div>
                                
                                <div class="form-group">
                                    <label for="gender">Gender</label><br>
                                    <label for="male">Male <input type="radio" name="gender" id="male" value="Male"></label><br>
                                    <label for="female">Female <input type="radio" name="gender" id="female" value="Female"></label><br>
                                    <label for="other">Other <input type="radio" name="gender" id="other" value="Other"></label><br>
                                </div>
                                
                                <div class="form-group">
                                    <label for="civilstat">Civil Status</label>
                                    
                                    <select name="civilstat" class="form-control">
                                        <option value="single">Single</option>
                                        <option value="married">Married</option>
                                        <option value="seperated">Seperated</option>
                                        <option value="widowed">Widowed</option>
                                    </select>
                                </div>
                                
                                
                                <div class="form-group">
                                    <label for="contactnum ">Contact Number</label>
                                    <input type="number" name="contactnum" placeholder="Contact Number" class="form-control" />
                                </div>
                                
                                <div class="form-group">
                                <label for="salary">Salary</label>
                                <input type="number" name="salary" placeholder="salary" class="form-control"/>
                                </div>
                                
                                <div class="form-group">
                                <label >is Active? </label>
                                    <input type="checkbox" id="isactive " name="isactive" value="1">
                                    <label for="isactive"> Active</label>
                                    <input type="checkbox" id="notActive" name="isactive"value="0">
                                    <label for="notActive"> Not Active</label><br>
                                </div>
                                
                                 
                            </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <input type="submit" value="Submit" class="btn btn-primary">
                            </form>
                        </div>
                </div>
            </div>