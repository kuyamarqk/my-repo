<!-- modal for view employee -->
<div class="modal fade" id="viewEmployee<?= $row['recid']?>" tabindex="-1" aria-labelledby="viewEmployeeLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="viewEmployeeLabel">View Employee</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">                 
<?php
$list = fetch_record("select * from employeefile where recid =". $row['recid']."");
?>
<div>
    <div class="form-group">
        <label for="empname">Employee Name</label>
        <input type="text" name="empname" value="<?= $list['fullname']?>" class="form-control" readonly>
    </div>
               
                <div class="form-group">
                    <label for="address">Address</label>
                    <input type="text" name="address" value="<?= $list['address']?>" class="form-control" readonly>
                </div>
                
                <div class="form-group">
                     <label for="bday">Birth Date</label>
                     <input type="date" name="bday" value="<?= $list['birthdate']?>" class="form-control" readonly>
                </div>
                
                <div class="form-group"> 
                    <label for="age">Age</label> 
                    <input type="number" name="age" value="<?= $list['age']?>" class="form-control" readonly>
                </div>
                
                <div class="form-group"> 
                    <label for="gender">Gender</label><br> 
                    <label for="male">Male<input type="radio" name="gender" id="male" readonly value="male" <?= ($list['gender'] == 'male')? 'checked' : ""; ?>></label><br>
                    <label for="female">Female<input type="radio" name="gender" id="female" readonly value="female" <?= ($list['gender'] == 'female')? 'checked' : ""; ?>></label><br>
                    <label for="other">Other<input type="radio" name="gender" id="other" readonly value="other" <?= ($list['gender'] == 'other')? 'checked' : ""; ?>></label><br>
                </div>
                
                <div class="form-group">  
                    <select name="civilstat" readonly class="form-control"> 
                        <option value="single" <?= ($list['civilstat'] == 'single')? "selected" : ''?>>Single</option>
                        <option value="married" <?= ($list['civilstat'] == 'married')? "selected" : ''?>>Married</option>
                        <option value="seperated" <?= ($list['civilstat'] == 'seperated')? "selected" : ''?>>Seperated</option>
                        <option value="widowed" <?= ($list['civilstat'] == 'widowed')? "selected" : ''?>>Widowed</option>
                    </select>
                </div>

                <div class="form-group">  
                    <label for="contactnum ">Contact Number</label> 
                    <input type="number" value="<?= $list['contactnum']?>" class="form-control" name="contactnum" placeholder="Contact Number" readonly>
                </div>

                <div class="form-group"> 
                    <label for="salary">Salary</label> 
                    <input type="number" value="<?= $list['salary']?>" name="salary" placeholder="salary" readonly class="form-control">
                </div>

                <div class="form-group"> Is Active? 
                    <input type="checkbox" <?= ($list['isactive'] == 1) ? 'checked':''?> value="1" id="isactive " name="isactive" readonly>
                    <label for="isactive"> Active</label>
                    <input type="checkbox" id="notActive" name="isactive" <?= ($list['isactive'] == 0) ? 'checked':''?> value="0" readonly>
                    <label for="notActive"> Not Active</label>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                
                
            </div>
</div>
               
        </div>
    </div>
</div>
<!-- Modal for update employee -->
<div class="modal fade" id="editEmployee<?= $row['recid']?>" tabindex="-1" aria-labelledby="addEmployeeLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="editEmployeeLabel">Edit Employee</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="proc.php" method="post" class="form-control">
            
            <div class="modal-body">                 
<?php
$list = fetch_record("select * from employeefile where recid =". $row['recid']."");
?>
                <input type="hidden" name="id" value="<?= $list['recid']?>">
                <input type="hidden" name="action" value="edit_employee">
                <div>
    <div class="form-group">
        <label for="empname">Employee Name</label>
        <input type="text" name="empname" value="<?= $list['fullname']?>" class="form-control" readonly>
    </div>
               
                <div class="form-group">
                    <label for="address">Address</label>
                    <input type="text" name="address" value="<?= $list['address']?>" class="form-control" readonly>
                </div>
                
                <div class="form-group">
                     <label for="bday">Birth Date</label>
                     <input type="date" name="bday" value="<?= $list['birthdate']?>" class="form-control" readonly>
                </div>
                
                <div class="form-group"> 
                    <label for="age">Age</label> 
                    <input type="number" name="age" value="<?= $list['age']?>" class="form-control" readonly>
                </div>
                
                <div class="form-group"> 
                    <label for="gender">Gender</label><br> 
                    <label for="male">Male<input type="radio" name="gender" id="male" readonly value="male" <?= ($list['gender'] == 'male')? 'checked' : ""; ?>></label><br>
                    <label for="female">Female<input type="radio" name="gender" id="female" readonly value="female" <?= ($list['gender'] == 'female')? 'checked' : ""; ?>></label><br>
                    <label for="other">Other<input type="radio" name="gender" id="other" readonly value="other" <?= ($list['gender'] == 'other')? 'checked' : ""; ?>></label><br>
                </div>
                
                <div class="form-group">  
                    <select name="civilstat" readonly class="form-control"> 
                        <option value="single" <?= ($list['civilstat'] == 'single')? "selected" : ''?>>Single</option>
                        <option value="married" <?= ($list['civilstat'] == 'married')? "selected" : ''?>>Married</option>
                        <option value="seperated" <?= ($list['civilstat'] == 'seperated')? "selected" : ''?>>Seperated</option>
                        <option value="widowed" <?= ($list['civilstat'] == 'widowed')? "selected" : ''?>>Widowed</option>
                    </select>
                </div>

                <div class="form-group">  
                    <label for="contactnum ">Contact Number</label> 
                    <input type="number" value="<?= $list['contactnum']?>" class="form-control" name="contactnum" placeholder="Contact Number" readonly>
                </div>

                <div class="form-group"> 
                    <label for="salary">Salary</label> 
                    <input type="number" value="<?= $list['salary']?>" name="salary" placeholder="salary" readonly class="form-control">
                </div>

                <div class="form-group"> Is Active? 
                    <input type="checkbox" <?= ($list['isactive'] == 1) ? 'checked':''?> value="1" id="isactive " name="isactive" readonly>
                    <label for="isactive"> Active</label>
                    <input type="checkbox" id="notActive" name="isactive" <?= ($list['isactive'] == 0) ? 'checked':''?> value="0" readonly>
                    <label for="notActive"> Not Active</label>
                </div>
            </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <input type="submit" value="Submit" class="btn btn-primary">
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal for delete employee -->
<div class="modal fade" id="deleteEmployee<?= $row['recid']?>" tabindex="-1" aria-labelledby="deleteEmployeeLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
        <form action="proc.php" method="post" class="form-class">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="deleteEmployeeLabel">Delete Employee</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
               <h1 class="text-bg-danger text-center col-lg">
                    Are You Sure you want  to delete this?
                </h1>
                <p class="col text-center">
                    <input type="hidden" name="id" value="<?= $row['recid']?>">
                    <input type="hidden" name="action" value="delete_employee">
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <input type="submit" value="Delete" class="btn btn-outline-danger">
            </div>
            </form>
        </div>
    </div>
</div>