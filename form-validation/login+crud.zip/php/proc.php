<?php
require('db.php');
session_start();
    if(isset($_GET['action']) && $_GET['action'] == 'Reg'){
        header('location: register.php');
    }
    if(isset($_GET['action']) && $_GET['action'] == 'Login'){
        header('location: index.php');
    }
    if(isset($_GET['action']) && $_GET['action'] == 'Logout'){
        logout();
    }
    if(isset($_POST['action']) && $_POST['action'] == 'register'){
        register($_POST);
    }
    if(isset($_POST['action']) && $_POST['action'] == 'Login'){
        login($_POST);
    }
    if(isset($_POST['action']) && $_POST['action'] == 'add_employee'){
        add_employee($_POST);
    }
    if(isset($_POST['action']) && $_POST['action'] == 'edit_employee'){
        edit_employee($_POST);
    }
    if(isset($_POST['action']) && $_POST['action'] == 'delete_employee'){
        delete_employee($_POST);
    }
function register($post){
    $username = $post['username'];
    $password = $post['password'];

    $sql = "INSERT into user (username, password) values ('$username', '$password')";

    if(run_mysql_query($sql)){
        echo "New record Created Successfully";
        header('location: index.php');
    }else{
        echo "Error: ". $sql ;
    }
}
function login($post){
    $username = $post['username'];
    $password = $post['password'];

    $sql = "Select * from user where username = '$username' and password ='$password'";
    $user = fetch_all($sql);
    if($user){
        foreach($user as $list){
            $_SESSION['id'] = $list['id'];
        }
        $_SESSION['id'];
        header("location: crud.php");
    }else{
        echo "Error: ".$sql;
    }
}
function add_employee($post){
    if($post['empname'] !== ""){
        $name = $post['empname'];
    }
    $address = $post['address'];
    $birthdate = $post['bday'];
    $age = $post['age'];
    $gender = $post['gender'];
    $civilstat = $post['civilstat'];
    $contactnum = $post['contactnum'];
    $salary = $post['salary'];
    $isactive = $post['isactive'];

    $sql = "insert into employeefile (fullname, address,birthdate,age,gender,civilstat,contactnum,salary,isactive) 
    values ('$name','$address','$birthdate', '$age', '$gender','$civilstat', '$contactnum', '$salary','$isactive')";
    echo $sql;

    if(run_mysql_query($sql)){
        header("location: crud.php");
    }else{
        echo "Error: ". $sql;
    }
}
function edit_employee($post){
    $id = $post['id'];
    $name = $post['empname'];
    $address = $post['address'];
    $birthdate = $post['bday'];
    $age = $post['age'];
    $gender = $post['gender'];
    $civilstat = $post['civilstat'];
    $contactnum = $post['contactnum'];
    $salary = $post['salary'];
    $isactive = $post['isactive'];

    $sql = "UPDATE employeefile
    SET fullname = '$name', 
        address = '$address', 
        birthdate = '$birthdate',
        age = '$age',
        civilstat = '$gender',
        contactnum = '$contactnum',
        salary = '$salary',
        isactive = '$isactive'
    WHERE recid = '$id'";
    run_mysql_query($sql);
    header("location: crud.php");
}
function delete_employee($post){
    $id = $post['id'];
    $sql = "Delete from employeefile where recid = '$id'";
    run_mysql_query($sql);
    header("location: crud.php");
}
function logout(){
    $_SESSION['id'] = '';
    header('location: index.php');
}
?>