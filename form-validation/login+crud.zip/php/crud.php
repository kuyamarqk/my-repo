<?php
session_start();
require_once("db.php");
if(empty($_SESSION['id'])){
    header("location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD</title>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <div class="row mb-3">
            <nav class="navbar navbar-expand-lg bg-light mb-3">
                <a class="navbar-brand" href="#"></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="proc.php?action=Logout">Logout</a>
                        </li>
                    </ul>
                </div>          
            </nav>
        </div>
        <div class="row mb-3">
            <button type="button" class="btn btn-primary col-sm-3" data-bs-toggle="modal" data-bs-target="#addEmployee">
                Add Employee
            </button>
        </div>
        <div class="row">
            <table class="table table-striped table-bordered table-hover">
                <thead>
                    <th>RecId</th>
                    <th>Employee name</th>
                    <th>Address</th>
                    <th>Birthdate</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Civil Status</th>
                    <th>Contact Number</th>
                    <th>Salary</th>
                    <th>isActive</th>
                    <th>Action</th>
                </thead>
                <tbody>
<?php $list = fetch_all("select * from employeefile");
                foreach($list as $row){ ?>
                    <tr>
                        <td><?= $row['recid']?></td>
                        <td><?= $row['fullname']?></td>
                        <td><?= $row['address']?></td>
                        <td><?= $row['birthdate']?></td>
                        <td><?= $row['age']?></td>
                        <td><?= $row['gender']?></td>
                        <td><?= $row['civilstat']?></td>
                        <td><?= $row['contactnum']?></td>
                        <td><?= $row['salary']?></td>
                        <td><?= ($row['isactive'] == 1) ? "Active": 'Not Active'?></td>
                        <td>

                            <a href="#viewEmployee<?= $row['recid']?>" data-bs-toggle="modal" class="btn btn-primary">View</a>
                            <a href="#editEmployee<?= $row['recid']?>" data-bs-toggle="modal" class="btn btn-warning">Edit</a>
                            <a href="#deleteEmployee<?= $row['recid']?>" data-bs-toggle="modal" class="btn btn-danger">Delete</a>
                            <?php include_once('modal/edit.php')?>
                        </td>
                    </tr>    
<?php           } ?>
                </tbody>
            </table>
        </div>
        <div class="row">
            <?php include_once('modal/add.php')?>  
        </div>       
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.min.js" integrity="sha384-IDwe1+LCz02ROU9k972gdyvl+AESN10+x7tBKgc9I5HFtuNz0wWnPclzo6p9vxnk" crossorigin="anonymous"></script>
</body>
</html>
