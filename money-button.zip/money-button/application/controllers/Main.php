<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {
	
	public $money;
	public $chance;
	public $logs;
	public $gameover;
	public $txtcolor;

	public function __construct(){
		parent::__construct();
		$this->load->library('session');
		$this->load->helper('url');
		$this->money = $this->session->userdata('money');
		$this->chance = $this->session->userdata('chance');
		$this->logs = $this->session->userdata('logs');
		$this->txtcolor = "default";
	}

	public function index()
	{
		$date = date("d M Y h:i:s A");
		
		$logs[] = [$this->txtcolor,"[".$date. "] Welcome to Money Button Game, risk taker! All you need to do is push buttons to try your luck. You have free 10 chances with initial money 500. Choose wisely and good luck!"];
		if($this->session->userdata('money') == null){
			$this->session->set_userdata('money',500);
			$this->session->set_userdata('chance',10);
		}
		else{
			$money = $this->money;
			$chance = $this->chance;
		}
		$this->session->set_userdata('logs',$logs);
		$data = array(
			'money' => $this->money,
			'chance' => $this->chance,
			'logs' => $logs
		);
		$this->load->view('main', $data);
	}
	public function proc()
	{
		$date = date("d M Y h:i:s A");
		
		$money = $this->money;
		$chances = $this->chance;
		$logs = $this->logs;
		$arr = array(
					'low'=>array(-25,100),
					'moderate'=>array(-100,1000),
					'high' => array(-500,2500),
					'severe' =>array(-3000,5000)
				);
		
		//button
		if($this->input->post('action') !== null && $this->input->post('action') == 'bet' ){
			foreach ($arr as $row => $key){
				if($this->input->post($row) !== null && $this->input->post($row) == 'Bet'){
					$ran = rand($key[0], $key[1]);
					$money = $money + $ran;
					$chances = $chances - 1;
					$msg = "[".$date. "] You pushed for ". $this->input->post($row).
								" value is ". $ran .
								" your current Money is ". $money .
								" with ". $chances ." ";
				}
				$this->session->set_userdata('money', $money);
				if($ran <= 0){
					$this->txtcolor = "lose";
				}elseif($ran > 0){
					$this->txtcolor = "win";
				}	
			}
			array_push($this->logs,array($this->txtcolor,$msg));
			
			$this->session->set_userdata('logs',$this->logs);
			$this->session->set_userdata('chance', $chances);	
		}	
		//chance = 0
		if($chances <= 0 || $money == 0){
			redirect('main/gameover');
		}
		$data = array(
			'money' => $money,
			'chance' => $chances,
			'logs' => $logs
		);
		
		$this->load->view('Main',$data);		
	}
	public function reset(){
		$this->session->unset_userdata('money');
		$this->index();
	}
	public function gameover(){
		$this->load->library('session');
		$this->session->set_userdata('gameover',true);
		$logs[] = array_push($this->logs, array($this->txtcolor, "Gameover"));
		$gameover = $this->session->userdata('gameover');
		$data = array(
			'gameover' => $gameover,
			'money' => $this->money,
			'chance' => $this->chance,
			'logs' => $this->logs
				);
		$this->load->view('main',$data);
	}
}
