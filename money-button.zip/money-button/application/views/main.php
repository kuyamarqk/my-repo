<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
		body{
    		margin: 0 auto;
    		padding : 0 auto;
		}
		.container{
    		width: auto;
		}

		.row .profile{
    		list-style: none;
   			vertical-align: top;
    		display: inline-block;
    		width: 25%
		}
		.row .reset{
    		list-style: none;
    		display: inline-block;
    		vertical-align: top;
    		padding-left: 50%;
    		padding-top: 25px;
		}
		.row .reset input{
    		background-color: red;
    		color: white;
    		border: 1px solid;
    		padding: 10px;
    		box-shadow: 5px 10px;
		}
		.bet{
    		margin: 80px 0px;
		}
		.bet ul li{
    		list-style: none;
    		display: inline-block;
    		padding: 30px 30px;
   			border: 1px solid black;
    		text-align: center;
		}
		.bet input{
    		background-color: green;
    		color: white;
    		border: 1px solid;
    		padding: 10px;
    		box-shadow: 5px 10px;
		}
		.console{
    		margin: 20px;
		}
		.console-host {
    		width: 870px;
    		height: 200px;
   			border: 1px solid black;
    		overflow-y: scroll;
		}
		.win{
    		color: green;
		}
		.lose{
    		color: red;
		}
	</style>
</head>
<body>
    <div class="container">
	<form action="<?= base_url("main/reset")?>" method="POST">
        <div class="row">
            <ul class =' profile'>
				
                <li><h4>Your Money: <?= $money;?></h4> </li>
                <li>Chances Left: <?= $chance;?></li>
            </ul>
            <ul class='reset'>
				<input type="hidden" name="action" value="reset">
                <li><input type="submit" value="Reset Game" name="reset"></li>
            </ul>
        </div>
    </form>
<?php if(isset($gameover) && $gameover == true){ ?>
<form action="" method="post">
<input type="hidden" name="action" value="bet">
<div class="bet">
		<ul>
			<li><p>Low Risk</p>
				<p><input type="submit" value="Bet" name="low"></p>
				<p>by -25 up to 100</p>
			</li>
			<li><p>Moderate Risk</p>
				<p><input type="submit" value="Bet" name="moderate"></p>
				<p>by -100 up to 1000</p>
			</li>
			<li><p>High Risk</p>
				<p><input type="submit" value="Bet" name="high"></p>
				<p>by -500 up to 2500</p>
			</li>
			<li><p>Severe Risk</p>
				<p><input type="submit" value="Bet" name="severe"></p>
				<p>by -3000 up to 5000</p>
			</li>
		</ul>
	</div>
</form>
<?php }else{?>
	<form action="<?= base_url("main/proc"); ?>" method="post">
	<input type="hidden" name="action" value="bet">
	<div class="bet">
            <ul>
                <li><p>Low Risk</p>
                    <p><input type="submit" value="Bet" name="low"></p>
                    <p>by -25 up to 100</p>
                </li>
                <li><p>Moderate Risk</p>
                    <p><input type="submit" value="Bet" name="moderate"></p>
                    <p>by -100 up to 1000</p>
                </li>
                <li><p>High Risk</p>
                    <p><input type="submit" value="Bet" name="high"></p>
                    <p>by -500 up to 2500</p>
                </li>
                <li><p>Severe Risk</p>
                    <p><input type="submit" value="Bet" name="severe"></p>
                    <p>by -3000 up to 5000</p>
                </li>
            </ul>
        </div>
	</form>
<?php }?>
    </div>
	<div class="console">
            <p>Game Host:</p>
            <div class="console-host">
<?php 			
				$i=0;
				foreach($logs as $row=>$key){ ?>
				<p class="<?= $key[0]?>"><?= $key[1]?></p>
<?php 
				$i++;
}?>

            </div>  
        </div>
</body>
</html>