<?php
    class Bookmarks extends CI_Model{
        function get_all_bookmarks(){
            return $this->db->query('SELECT * FROM tbl_bookmark');
        }
        function add_bookmarks($post){
            $query = "INSERT INTO tbl_bookmark(name,url,folder) values (?,?,?)";
            $value = $post;
            return $this->db->query($query, $value);          
        }
        function delete($id){
            return $this->db->query("DELETE FROM tbl_bookmark where id= $id");
        }
        function get_by_id($id){
            return $this->db->query("SELECT * FROM tbl_bookmark where id=$id")->result_array();
        }
    }
?>