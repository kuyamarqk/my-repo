<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main extends CI_Controller {
	
	public function __construct(){
		parent::__construct();
		$this->load->model('bookmarks');
        $this->load->helper(array('url','form'));
        $this->load->database();
		$this->load->library(array("form_validation","session"));
	}

	public function index()
	{
		$this->output->enable_profiler(TRUE);
		$this->load->model('Bookmarks');
		$data['myData'] = $this->Bookmarks->get_all_bookmarks();
		$this->load->view('Main',$data);
	}
	public function add()
	{	
		$this->load->library('form_validation');
		$this->load->model('Bookmarks');
		$post = $this->input->post();
		$result = $this->validate($post);
		$add_bookmarks = $this->Bookmarks->add_bookmarks($post);
			if($add_bookmarks === true){
				echo "Bookmarks has been added!";
			}
		$add_bookmark = $this->Bookmarks->add_bookmarks($result);
		
	}
	public function delete($id)
	{
		$this->load->model('Bookmarks');
		$result['all'] = $this->Bookmarks->get_by_id($id);
		$this->load->view('delete',$result);
	}
	public function deleting($id)
	{
		$this->load->model('Bookmarks');
		$result = $this->Bookmarks->delete($id);
		if($result === true){
			redirect('main');
		}else{
			echo "there is an error deleting this bookmark";
			$this->load->view('main');
		}
	}
	public function validate($post){
		$this->load->library('form_validation');
		$this->form_validation->set_rules($post['url'],"url","valid_url");
		$this->form_validation->set_rules($post['name'],'name','trim|required');
		$this->form_validation->set_rules($post['folder'],'folder','trim|required');
    	if($this->form_validation->run()) {
      		return "valid";
   		} else {
     		return array(validation_errors());
    	}
	}
}

